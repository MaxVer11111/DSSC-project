# 成员 1 → 成员 2：统一数据交付与 Demo 使用说明

本目录汇总了 A、C、D 三组交付给 B 组成员 2 的数据、语义模型、映射说明和验证证据。本文是统一入口；子目录中的 README 用于补充各来源组的细节。

审计日期：2026-08-12（Asia/Shanghai）  
当前文件数：71（包含本 README）  
当前总体状态：**静态 Credential 草稿可以准备；包含 JSON-LD 解析、真实 Endpoint 调用和 D 组验证的端到端 Demo 尚未就绪。第 3 节的“必须解决”项完成后才能进行完整演示。**

## 1. 本次重新检查的结论

### 已确认正常

- C 组原始目录 `C组数据整理/B组-C组对接包/` 已移入本交付目录，不再依赖父目录中的外部 C 原始文件夹。
- C 原始包 `SHA256SUMS.txt` 登记的 32 个业务文件全部存在，实际 SHA-256 全部匹配。
- 当前共有 4 份哈希清单、61 个登记条目：60 个通过，1 个因 D 组 README 改名而找不到旧文件名；文件内容本身未变化。
- 71 个文件中没有两个文件共享同一 SHA-256，未发现哈希碰撞或重复内容。
- 24 个 `.json` / `.jsonld` 文件均能按 JSON 语法解析，未发现重复键。
- `D组数据整理/source/To_B.zip` 中的 8 个文件与解压目录逐字节一致。
- 4 份 PDF 共 17 页，均可打开和完整读取；报告结果与 `d-validation-summary.json` 中的 SUCCESS/FAILURE 和 findings 数量一致。

### 仍存在的问题

- C 原始目录虽然已经移入，但 C 派生文件仍使用移动前的旧相对路径，导致 `current-demo-metadata.jsonld` 的 `@context` 断链。
- D 组局部 README 已从 `README-成员2使用说明.md` 改名为 `README.md`，但 D 组 `SHA256SUMS.txt` 仍登记旧文件名。
- A/C 当前 Demo 数据与 D 验证样例不是同一个 metadata 对象；URI、语义结构、Endpoint 和 Format 不一致。
- Provider DID、Offering ID、Dataset URI 和最终 Shapes 版本尚未形成一份供 Demo 程序统一读取的冻结配置。

## 2. 当前建议使用的字段

### 可直接用于 Demo 草稿

| 字段 | 当前值 | 使用说明 |
|---|---|---|
| Dataset ID | `building-energy-hourly-v1` | A/C/D 一致，可作为跨组核对键 |
| Provider name | `Energy Data Provider Ltd.` | A/C/D 一致；不能代替 Provider DID |
| Offering name | `Building Energy Consumption Dataset API` | A/D 一致 |
| License | `https://creativecommons.org/licenses/by/4.0/` | A/D 一致；最终验证输入中必须实际包含该字段 |
| Frequency | `hourly` | C/D 一致，只放 Dataset metadata |
| Unit | `kWh` | C/D 一致，只放 Dataset metadata/记录层 |
| Spatial coverage | `Shenzhen demo district` | C/D 一致，仅表示 Demo 范围 |
| Temporal range | `2026-05-01` 至 `2026-05-02` | C/D 一致，只放 Dataset metadata |

### Demo 前需要冻结的值

| 字段 | 建议的本轮 Demo 值 | 当前风险 |
|---|---|---|
| Provider DID | `did:web:mp-operations.org` | A/C 使用；D 未提供。若成员 2 的旧 LegalPerson 仍含 `example.org` 占位身份，会造成跨 Credential 不一致 |
| Service Offering ID | `urn:dssc:service-offering:building-energy-hourly-v1` | 当前仍标记 `proposed-pending-ab-confirmation` |
| Dataset canonical URI | `urn:dssc:dataset:building-energy-hourly-v1` | A/C 使用；D 样例使用不同 HTTP URI |
| Endpoint | `https://scorpio-provider.127.0.0.1.nip.io/ngsi-ld/v1/entities/urn:ngsi-ld:Building:BLD-001` | 仅本地 Real Cluster 可达；D 验证样例使用 `example.org` Endpoint |
| Response media type | `application/ld+json` | A 的实际接口值；D Shapes 当前强制 `application/json` |
| C semantic model | `v0.3`，hash 见 `model-version.json` | `draft / Research demo release candidate` |
| D validation profile | 建议本轮采用 D 最新文件，SHA-256 `17DACE38CB949796D3BDEF0D5BA3002763A5FAC84FF56650F886CDCF8E6AE53D` | C 原包登记的旧 D profile 哈希为 `A556039C...` |

## 3. 问题分类：哪些必须解决，哪些可以暂时忽略

### 3.1 影响 Demo 可运行性——必须解决

以下问题会造成文件加载失败、校验失败、现场接口调用失败，或让 Demo 输出的 Credential 相互矛盾。

| 编号 | 必须解决的问题 | 直接影响 | Demo 前的最小解决方案 |
|---|---|---|---|
| RUN-01 | C 派生文件仍引用 `../B组-C组对接包/...`，但原始包现在位于 `C组数据整理/B组-C组对接包/` | `current-demo-metadata.jsonld` 无法解析本地 `@context`；依赖该文件的 JSON-LD/SHACL 步骤会失败 | 将 `current-demo-metadata.jsonld`、`c-to-b-data-summary.json` 中的路径改为 `B组-C组对接包/...`；同步更新 `source-register.md`。修改后重算 `C组数据整理/SHA256SUMS.txt` |
| RUN-02 | D 组 `SHA256SUMS.txt` 仍登记 `README-成员2使用说明.md`，实际文件已改名为 `README.md` | 如果 Demo 启动前执行完整性预检，预检会报 MISSING 并中止 | 二选一：把文件名改回旧名；或把清单条目改为 `README.md`。内容 SHA-256 仍为 `DB5E0C45EB5483974ED302B5E596AF087D5F1788E680AE5EB48F622947FFDCE6` |
| RUN-03 | A/C 的当前 metadata 与 D 的验证 profile/样例不是同一结构 | 直接把 `current-demo-metadata.jsonld` 送给 D Shapes 时，会遇到类型、namespace、字段路径和 Format 不匹配；TC02 还会因 C metadata 没有 License 而失败 | 生成一份专用 `canonical-demo-metadata.jsonld`，明确转换 C 字段到 D/A 最终结构；必须包含唯一 Dataset、Provider name、Title、License、Endpoint、时间范围等。不要覆盖任何原始样例 |
| RUN-04 | A 实际响应是 `application/ld+json`，D Shapes 强制 `application/json` | 最终对象无法同时“符合实际接口”又“通过当前 D FormatShape” | 推荐修改并冻结 D Shapes，使其接受实际 `application/ld+json`，然后生成新 Shapes 哈希并重跑验证；若坚持 `application/json`，则 Demo 服务必须真实返回该类型，不能只改文档 |
| RUN-05 | Provider DID、Offering ID、Dataset URI 没有一份统一的 Demo 配置 | Credential 生成器、验证器和展示脚本可能各自读取不同值，造成引用断裂 | 在 Demo 范围内先冻结第 2 节建议值，建立一份 `demo-config.json`；LegalPerson subject、ServiceOffering subject/providedBy、Dataset URI 全部从该文件读取。生产级确认可在 Demo 后继续 |
| RUN-06 | C 登记的旧 D Shapes 与 D 最新 Shapes 哈希不同 | 不同机器可能加载不同规则，导致同一 metadata 得到不同结果 | 本轮 Demo 只使用一个规则文件。建议使用 D 最新 `17DACE38...`；验证器配置、输出报告和 evidence manifest 必须记录同一完整哈希 |
| RUN-07 | A Endpoint 是本机 `127.0.0.1.nip.io` 地址 | 如果 Real Cluster 未启动，或 Demo 在另一台机器运行，现场数据访问会失败 | 若 Demo 包含实时调用，演示前执行 GET smoke test；保证集群已启动。若只做离线演示，应准备明确标记为 snapshot 的响应文件并让脚本切换到离线模式 |
| RUN-08 | D 文档称 B 组旧 LegalPerson 可能仍使用 `example.org` 占位身份，但该旧 Credential 不在本包中 | 若真实 Demo 仍加载旧 Credential，`providedBy` 关系可能无法通过一致性检查 | 成员 2 在自己的 Credential 工作目录核对并替换占位 ID；如果 Demo 不读取旧 Credential，也要确保新草稿只使用冻结后的 Provider DID |

### 3.2 不影响本轮 Demo 运行——可以暂时忽略

这些问题影响生产合规、审计复现或文档质量，但不会直接阻止本轮课程/项目 Demo 启动。可以暂缓，不过必须在展示说明中如实标注。

| 编号 | 可暂时忽略的问题 | 为什么暂不阻塞 | Demo 中的处理方式 |
|---|---|---|---|
| DEFER-01 | C 原始 ZIP `B组-C组对接包_2026-08-10.zip` 没有移入当前目录 | 解压后的 33 个文件已经存在，32 个业务文件哈希全部通过 | 使用目录版；后续若需要原始归档再补 ZIP |
| DEFER-02 | A 的 `evidenceSource` 指向未交付的 `demo-real-20260704-203904.log` | 不影响读取当前 JSON 或生成草稿，只影响运行证据追溯 | 展示时只说“历史运行快照”，不要声称已在本包内完整复现日志 |
| DEFER-03 | PDF 没有绑定上传文件名、metadata SHA-256 和 Shapes SHA-256 | 不影响打开 PDF 或展示既有成功/失败结果，只影响不可抵赖性 | 将 PDF 表述为“D 样例验证证据”，不要表述为“A 实际发布 metadata 的验证证据” |
| DEFER-04 | 缺少 Validator 正式版本/Endpoint、时区、机器可读 SHACL/ITB 结果和 Authority 白名单原文件 | 已有环境若能运行，Demo 仍可展示；但别人难以完全复现 | 课程 Demo 可暂缓，正式审计前必须补齐 |
| DEFER-05 | A 的 5 个派生文件和根 README 没有被统一顶层哈希清单覆盖 | 不影响程序读取；现有原始文件和关键 D/C 文件已有局部清单 | 所有内容冻结后再生成一个根级 `SHA256SUMS.txt` |
| DEFER-06 | A 的 retention 一处是 `"not-defined"`，另一处是 `null` | 本轮 Demo 不使用实际保留期限策略 | 草稿统一按“未定义”处理，不展示具体期限 |
| DEFER-07 | C 子目录文档仍写 `PENDING_D` / “D 组尚未交付” | D 文件实际已存在，属于局部文档过期 | 以本 README 为最新状态；有时间再同步子文档 |
| DEFER-08 | `D组数据整理/open-issues.md` 声称 `valid_TC02.pdf` 第 4 页被裁切 | 本次重新渲染确认标题和正文完整，没有裁切 | 忽略该描述，后续删除或改成“复核正常” |
| DEFER-09 | Provider 法律身份、LRN、正式 Trust Anchor、公开 DID、T&C、公钥/证书链等生产材料未闭环 | 课程 Demo 可以使用明确标记的本地/候选身份 | 不得宣称已获得生产级 Gaia-X trust/compliance |
| DEFER-10 | A 的 negotiation `AGREED` 和 transfer `COMPLETED` 来自模拟状态机 | 模拟流程本身可以运行 | 展示时必须明确说“模拟”，不能说是 Connector API 实际执行结果 |
| DEFER-11 | A 与 D 的 Offering description 文案略有差异 | 不影响 ID、解析或校验流程 | Demo 统一采用 A 文案；正式版本后续冻结 |

## 4. Demo 前执行清单

按以下顺序完成，能够最少返工：

1. 修正 C 派生文件中的相对路径，并验证 `current-demo-metadata.jsonld` 能加载本地 context。
2. 修正 D 组 README 文件名与 `SHA256SUMS.txt` 的对应关系，运行全部哈希预检。
3. 创建 `demo-config.json`，冻结 Provider DID、Offering ID、Dataset URI、Endpoint、media type 和 Shapes SHA-256。
4. 从 A/C 字段生成新的 `canonical-demo-metadata.jsonld`；加入 License，不直接复用 D 的 `example.org` 样例。
5. 解决 `application/ld+json` 与 D `application/json` 的冲突，冻结唯一 Shapes 文件。
6. 用最终 canonical metadata 重新执行 TC01 和 TC02；同时保留 Valid/Invalid 回归用例。
7. 若现场调用 A Endpoint，先完成 GET smoke test；否则准备明确标记的离线 snapshot。
8. 生成未签名 Credential，检查 LegalPerson ID、ServiceOffering ID、`providedBy` 和 Dataset URI 是否全部来自 `demo-config.json`。
9. 最后再签名；任何字段或哈希变化后都重新生成签名。

建议 `demo-config.json` 至少包含：

```json
{
  "providerDid": "did:web:mp-operations.org",
  "serviceOfferingId": "urn:dssc:service-offering:building-energy-hourly-v1",
  "datasetUri": "urn:dssc:dataset:building-energy-hourly-v1",
  "endpoint": "https://scorpio-provider.127.0.0.1.nip.io/ngsi-ld/v1/entities/urn:ngsi-ld:Building:BLD-001",
  "responseMediaType": "application/ld+json",
  "semanticModelVersion": "v0.3",
  "validationShapesSha256": "17DACE38CB949796D3BDEF0D5BA3002763A5FAC84FF56650F886CDCF8E6AE53D"
}
```

## 5. 数据目录与使用顺序

### 5.1 A 组：身份、Offering 和实际部署信息

成员 2 建议按以下顺序读取：

1. `A组数据整理/a-to-b-data-summary.json`：A→B 当前 Demo 主摘要。
2. `A组数据整理/field-mapping.md`：LegalPerson/ServiceOffering 字段映射。
3. `A组数据整理/demo-notes.md`：真实集群与模拟流程的边界。
4. `A组数据整理/A组原始文件/offering-manifest.json`：Offering、Dataset、条款和部署实例。
5. `A组数据整理/A组原始文件/provider-profile.json`：Provider DID、名称和 TIR 观察状态。
6. `A组数据整理/A组原始文件/openapi-scorpio.yaml`：本地 Scorpio API。

其他 A 文件：

| 文件 | 用途 |
|---|---|
| `connector-publication-result.json` | Catalogue/TIR/资源访问历史快照 |
| `contract-transfer-result.json` | 模拟协商与传输状态 |
| `dssc-ab.md` | A/B 标识分层和详细说明 |
| `source-register.md` | GitHub 路径和 Git blob SHA 登记 |
| `A组原始文件/SHA256SUMS.txt` | 6 个 A 原始文件的 SHA-256 |

### 5.2 C 组：语义模型、字段定义和派生 metadata

成员 2 建议按以下顺序读取：

1. `C组数据整理/c-to-b-data-summary.json`：C v0.3 与 A 实值的对齐摘要。
2. `C组数据整理/current-demo-metadata.jsonld`：当前派生 metadata；必须先修复 `@context` 路径。
3. `C组数据整理/field-mapping.md`：Credential、evidence 和 Dataset-only 字段分层。
4. `C组数据整理/B组-C组对接包/model-version.json`：模型版本及关键工件哈希基线。
5. `C组数据整理/B组-C组对接包/context.jsonld`、`vocabulary.ttl`、`metadata-shapes.ttl`：C v0.3 核心模型。

C 原始包分区：

| 路径 | 内容 |
|---|---|
| `B组-C组对接包/` | 原始需求、context、valid/invalid 样例、模型版本、字段定义、映射、核心 Shapes、语义模型、README、清单和发送说明 |
| `B组-C组对接包/d-validation-profile/` | C 原包登记的旧 D validation profile、D context 和 D valid/invalid 样例 |
| `B组-C组对接包/energy-reading-record/` | Record context、JSON Schema、SHACL、OpenAPI fragment 和 valid/invalid 样例 |
| `B组-C组对接包/evidence/` | 本地部署、smoke check、全量验证和交付验证记录 |
| `B组-C组对接包/governance/` | changelog、model card、namespace policy 和 provenance |
| `B组-C组对接包/SHA256SUMS.txt` | 除清单自身外 32 个 C 原始业务文件的 SHA-256 |

### 5.3 D 组：验证输入、Shapes 和报告

成员 2 建议按以下顺序读取：

1. `D组数据整理/service-offering-input-from-d.json`：D→成员 2 的机器可读主入口。
2. `D组数据整理/consistency-matrix.md`：A/B/C/D 字段冲突和 Shapes 版本差异。
3. `D组数据整理/open-issues.md`：详细 P0/P1 清单；PDF 裁切项已被本次复核否定。
4. `D组数据整理/d-validation-summary.json`：4 份 PDF 的 findings 汇总。
5. `D组数据整理/source/To_B/shacl-rules/building-energy-shapes_D.ttl`：D 最新 Shapes。
6. `D组数据整理/source/To_B/metadata/`：D valid/invalid 样例，只用于验证回归。
7. `D组数据整理/source/To_B/validation-reports/`：两份 Valid 和两份 Invalid PDF。

注意：`D组数据整理/source/To_B/metadata/data-product-valid.jsonld` 通过的是 D 样例流程，不是 A 的实际发布 metadata，也不是修复后的 C `current-demo-metadata.jsonld`。

## 6. 可以声明与不能声明的结果

### 当前可以声明

- C 原始目录已经移入，32 个业务文件哈希全部匹配。
- 除 D README 改名造成的一个清单路径错误外，其余 60 个哈希条目全部通过。
- D ZIP 与解压目录一致。
- A 提供了本地 Real Cluster 的 Provider、Catalogue 发布和 Scorpio 资源访问历史证据。
- D valid 样例通过现有报告所描述的验证流程，invalid 样例被正确拒绝。
- A/C/D 在 Dataset ID、Provider name、标题、License、频率、单位和 Demo 时空范围上存在可复用的一致值。

### 当前不能声明

- 端到端 Demo 已可直接运行；RUN-01 至 RUN-08 尚未全部关闭。
- D 已验证 A 实际发布 metadata 或 C 当前派生 metadata。
- PDF 与当前 JSON-LD/TTL 已形成字节级不可抵赖绑定。
- Provider DID、Offering ID、Dataset URI、Endpoint、media type 和 Shapes 版本已形成生产级最终决议。
- 已完成 Gaia-X trust/compliance，或 D metadata 报告等同于 Gaia-X Compliance Credential。
- 模拟合同协商与传输是 Connector API 的真实执行结果。

