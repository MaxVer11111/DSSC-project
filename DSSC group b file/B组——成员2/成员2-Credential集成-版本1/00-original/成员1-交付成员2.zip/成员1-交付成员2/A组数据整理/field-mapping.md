# A 组数据到 B 组 Credential 字段映射

本文件供成员2制作当前演示用 `LegalPerson` 和 `ServiceOffering` Credential。

## 必用映射

| A 组数据 | 当前 Demo 值 | 成员2使用位置 |
|---|---|---|
| Provider ID | `did:web:mp-operations.org` | `LegalPerson.credentialSubject.id` |
| Provider ID | `did:web:mp-operations.org` | `ServiceOffering.gx:providedBy` |
| Provider name | `Energy Data Provider Ltd.` | LegalPerson 名称字段 |
| Canonical Service Offering ID | `urn:dssc:service-offering:building-energy-hourly-v1` | `ServiceOffering.credentialSubject.id` |
| Offering name | `Building Energy Consumption Dataset API` | `ServiceOffering.gx:name` 或当前 profile 对应名称字段 |
| Offering description | `Hourly energy consumption data for buildings in Shenzhen` | `ServiceOffering.gx:description` 或当前 profile 对应描述字段 |
| Dataset URI | `urn:dssc:dataset:building-energy-hourly-v1` | `ServiceOffering.gx:aggregationOf` |
| License URL | `https://creativecommons.org/licenses/by/4.0/` | ServiceOffering 的 license/terms 对应字段 |
| Policy | research、analytics、署名、禁止再分发 | `gx:policy` 或当前 profile 对应字段 |

## 仅作部署证据，不作 Credential 主体 ID

以下运行实例 ID 用于说明 A 组已经完成发布，不应写入 `ServiceOffering.credentialSubject.id`：

```text
ProductOffering ID:
urn:ngsi-ld:product-offering:9bf7b573-12c9-4e5c-8761-6df190965aa7

ProductSpecification ID:
urn:ngsi-ld:product-specification:76ab9aad-8dc2-43c2-a6db-7191494a96eb
```

数据资源和访问方式可作为演示附件或 ServiceOffering 技术说明：

```text
Resource ID: urn:ngsi-ld:Building:BLD-001
Method: GET
Media type: application/ld+json
Endpoint: https://scorpio-provider.127.0.0.1.nip.io/ngsi-ld/v1/entities/urn:ngsi-ld:Building:BLD-001
```

## 成员2生成前检查

- `LegalPerson.credentialSubject.id` 与 `ServiceOffering.gx:providedBy` 相同。
- `ServiceOffering.credentialSubject.id` 使用 Canonical ID，而不是 TMForum UUID。
- `gx:aggregationOf` 使用 Dataset URI，而不是 Scorpio Resource ID。
- 不使用旧占位值 `did:web:energy-provider.example.org`。
- 不使用旧占位 endpoint `https://api.example.org/energy/buildings/hourly`。
