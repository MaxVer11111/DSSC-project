# A→B Demo 交接说明

## 本次演示采用的约定

1. A 组正式数据基线采用 FIWARE Real Cluster，不采用 Mock Demo 生成的 ID。
2. 当前 Demo 统一使用 `did:web:mp-operations.org` 作为 Provider ID。
3. 当前 Demo 使用稳定的 Canonical Service Offering ID：`urn:dssc:service-offering:building-energy-hourly-v1`。
4. 当前 Demo 使用 Dataset URI：`urn:dssc:dataset:building-energy-hourly-v1`。
5. TMForum ProductOffering UUID 仅表示一次部署发布记录。

## 三项必要限制说明

- Scorpio endpoint 是本机 Real Cluster 的 `nip.io` 地址，不是公开线上服务。
- Catalogue 发布、TIR 查询和 Scorpio 数据访问具有 Real Cluster 运行证据。
- Contract negotiation 的 `AGREED` 和 transfer 的 `COMPLETED` 来自本地模拟状态机，不是 Connector API 执行结果。

## Demo 展示时建议说法

> A 组提供真实集群中的 Provider、Catalogue 发布和数据资源访问证据；B 组将这些稳定业务标识映射为 Gaia-X LegalPerson 和 ServiceOffering Credential。合同协商与传输状态用于演示流程串联，目前仍是本地模拟。

## 本轮不处理

由于目标是课程/项目演示，本轮不展开生产级法律身份、公开 DID 基础设施、正式 Trust Anchor、长期数据保留策略或公网 endpoint 建设。
