# A 组源文件登记

获取日期：2026-08-11  
仓库：`ShenYouSOTA/DSSC-Toolbox`  
分支：`master`

| 本地文件 | GitHub 路径 | Git blob SHA |
|---|---|---|
| `dssc-ab.md` | `dssc-ab.md` | `9a689d3199d530b4f82a9b577c64d6f8e715eeb9` |
| `provider-profile.json` | `demo/deliverables/provider-profile.json` | `128076b6e0e06176ca0085973497b0d6e2090589` |
| `offering-manifest.json` | `demo/deliverables/offering-manifest.json` | `c9ba6f853c00487db955bd9714dae5374880fc9c` |
| `connector-publication-result.json` | `demo/deliverables/connector-publication-result.json` | `5a32dc495649e536b212b23547812bed1871c24d` |
| `contract-transfer-result.json` | `demo/deliverables/contract-transfer-result.json` | `fb7bc4b13f4a782ae4062e23010dd59b1b4acaac` |
| `openapi-scorpio.yaml` | `demo/deliverables/openapi-scorpio.yaml` | `3d976eedf0d1ae699df0e9e0ffbc696df124d9a8` |

这些 SHA 是 GitHub blob SHA，用于标识读取时的仓库内容版本；不是本地文件的 SHA-256。
