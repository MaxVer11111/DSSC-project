# B 组成员1向成员2交接包

本目录已将 A 组 Real Cluster 交付整理成成员2可以直接用于 Credential 制作的 Demo 输入。

## 使用顺序

1. 成员2先阅读 `a-to-b-data-summary.json`，获取本次 Demo 的统一字段值。
2. 按 `field-mapping.md` 更新 LegalPerson 和 ServiceOffering Credential。
3. 阅读 `demo-notes.md`，在测试报告和最终展示中保留必要的 Demo 限制说明。
4. 如需追溯来源，查看 `A组原始文件/`，不要直接修改其中的文件。

## 目录内容

```text
B组-A组Demo交接包/
├── README.md
├── a-to-b-data-summary.json
├── field-mapping.md
├── demo-notes.md
├── source-register.md
└── A组原始文件/
    ├── dssc-ab.md
    ├── provider-profile.json
    ├── offering-manifest.json
    ├── connector-publication-result.json
    ├── contract-transfer-result.json
    ├── openapi-scorpio.yaml
    └── SHA256SUMS.txt
```

## 成员1交接结论

- Provider、Canonical Service Offering、TMForum 发布实例、Dataset 和 Resource ID 已分开。
- 已移除旧 `example.org` 占位值对本次 Demo 的影响。
- Endpoint 已与 A 组 Real Cluster 的 OpenAPI 对齐。
- 模拟的 negotiation/transfer 已明确标注，不会被误写成真实 Connector 执行结果。
- 本交接包不包含私钥、密码或 token。
