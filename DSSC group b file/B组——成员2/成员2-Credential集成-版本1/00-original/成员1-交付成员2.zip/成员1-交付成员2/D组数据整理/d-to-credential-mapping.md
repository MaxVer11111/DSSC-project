# D 组字段到成员 2 Credential 工作的映射

## 映射原则

D 组交付主要是 Dataset metadata 和 metadata conformance evidence。它可以补充 ServiceOffering 的数据集描述，但不提供 Provider 的法定身份、DID、Offering ID、签名材料或 VP-JWT。

| D 组字段/证据 | 建议用于 | 当前状态 | 成员 2 操作 |
|---|---|---|---|
| `datasetId` | ServiceOffering 引用的 Dataset 标识 | `MATCH` | 可使用 `building-energy-hourly-v1`，但 Dataset URI 需另行确认 |
| JSON-LD `@id` | Dataset URI / `gx:aggregationOf` 的引用对象 | `MISMATCH` | 不使用 D 组 `example.org` URI；等待 A/C 确认 canonical URI |
| `providerName` | LegalPerson 名称核对、ServiceOffering 展示信息 | `MATCH` | 可作为名称输入，但不能代替 Provider DID/ID |
| `dct:title` | ServiceOffering 名称 | `MATCH` | 可使用 |
| `dct:description` | ServiceOffering 描述 | `VARIANT` | 优先采用 A 组冻结描述 |
| `endpointUrl` | ServiceOffering 技术访问描述 | `MISMATCH` | 不签入 D 组示例 Endpoint；使用 A 组实际部署值 |
| `format` | 数据导出/响应格式描述 | `MISMATCH` | 先统一 MIME 值，再生成 Credential |
| `license` | ServiceOffering 条款或许可证引用 | `MATCH_A_D` | 可使用 CC-BY-4.0 URL；仍需与 Connector 实际策略共同确认 |
| `frequency`、`unit`、空间和时间范围 | 关联 Dataset metadata | `MATCH_C_D` | 保留在 Dataset metadata；无需强行塞入 Gaia-X Credential |
| D Shapes 哈希 | Evidence manifest 中的规则版本 | `MISMATCH_WITH_C_REGISTER` | 冻结最终 Shapes 后只登记一个 canonical hash |
| Valid TC01/TC02 PDF | Metadata conformance evidence | `AVAILABLE` | 作为外部证据引用，不作为 Compliance Credential |
| Invalid TC01/TC02 PDF | 负向测试证据 | `AVAILABLE` | 用于拒绝路径，不与正式 Offering 绑定 |

## Provider/Offering 身份材料仍需从其他来源取得

成员 2 仍需由 A 组或项目身份负责人确认：

- Provider DID / participant ID
- LegalPerson `credentialSubject.id`
- ServiceOffering `credentialSubject.id`
- Offering ID 的冻结状态
- Dataset canonical URI
- 实际 Endpoint 和响应 MIME type
- Connector 中的 policy/contract 与 Credential 声明的一致性
- LRN、T&C、DID Document、公钥/证书链和签名后的 VP-JWT

## 验证结果的正确放置

建议在最终 evidence manifest 中分开记录：

```json
{
  "trustCompliance": {
    "owner": "Group B",
    "status": "PENDING",
    "evidence": []
  },
  "metadataConformance": {
    "owner": "Group D",
    "status": "PASSED_FOR_D_SAMPLE",
    "evidence": [
      "valid_TC01.pdf",
      "valid_TC02.pdf"
    ]
  }
}
```

只有 B 组 trust/compliance 通过，且 D 组验证对象确认就是 A 组实际发布对象时，才可以给出整体 `ACCEPTED`。

