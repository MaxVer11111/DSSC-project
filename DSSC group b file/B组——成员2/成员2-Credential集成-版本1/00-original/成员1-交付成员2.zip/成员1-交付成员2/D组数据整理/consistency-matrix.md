# A/B/C/D 关键字段一致性矩阵

## 状态说明

- `MATCH`：值一致，可继续使用。
- `MISMATCH`：存在冲突，签名前必须解决。
- `MISSING`：来源未提供。
- `PENDING`：已有候选值，但尚未冻结。
- `SEPARATE_LAYER`：不是同一语义层，不应直接视作冲突，但必须分别标记版本。

## 核对结果

| 字段 | A 组 | B 组现有材料 | C 组 | D 组 To_B | 状态 | 结论 |
|---|---|---|---|---|---|---|
| `datasetId` | `building-energy-hourly-v1` | 目标值相同 | `building-energy-hourly-v1` | `building-energy-hourly-v1` | `MATCH` | 可交给成员 2 |
| Provider name | `Energy Data Provider Ltd.` | 相同 | 相同 | 相同 | `MATCH` | 可交给成员 2 |
| Provider ID | `did:web:mp-operations.org` | 旧 LegalPerson 使用 `energy-provider.example.org` 占位身份 | 未提供 | 未提供 | `MISMATCH/MISSING` | 先统一 Provider DID 与 LegalPerson ID |
| Offering ID | `urn:dssc:service-offering:building-energy-hourly-v1`，状态为 proposed pending | 未冻结 | 未提供 | 未提供 | `PENDING` | 不应签名，需 A/B 确认 |
| Dataset URI | `urn:dssc:dataset:building-energy-hourly-v1`，状态 pending | 未冻结 | `urn:dssc:dataset:building-energy-hourly-v1` | `https://example.org/dssc-energy/datasets/building-energy-hourly-v1` | `MISMATCH` | D 组值只是样例 URI |
| Endpoint | Scorpio 本地实际 Endpoint | 未冻结 | 与 A 组 Scorpio Endpoint 相同 | `https://api.example.org/energy/buildings/hourly` | `MISMATCH` | 使用 A 组部署值前需重做/确认 D 验证 |
| Format | `application/ld+json` | 未冻结 | `JSON` | `application/json` | `MISMATCH` | 统一规范化 MIME type |
| License | CC-BY-4.0 | 未冻结 | current demo metadata 未声明 | CC-BY-4.0 | `MATCH_A_D/MISSING_C` | 可作为候选值，但需补齐 C/实际发布对象 |
| Frequency | 未明确 | 未使用 | `hourly` | `hourly` | `MATCH_C_D` | Dataset metadata 可用 |
| Unit | 未明确 | 未使用 | `kWh` | `kWh` | `MATCH_C_D` | Dataset metadata 可用 |
| Spatial coverage | Shenzhen 语义 | 未使用 | `Shenzhen demo district` | `Shenzhen demo district` | `MATCH_C_D` | Dataset metadata 可用 |
| Temporal range | 未明确 | 未使用 | `2026-05-01` 至 `2026-05-02` | 相同 | `MATCH_C_D` | Dataset metadata 可用 |
| 主语义模型 | 未登记 | 未登记 | `v0.3`，`w3id.org/dssc-demo/...` | D Profile `v1.1`，`example.org/dssc-energy#` | `SEPARATE_LAYER` | C v0.3 与 D validation profile 分开记录 |
| D Shapes SHA-256 | 未登记 | 未登记 | `A556039C...` | `17DACE38...` | `MISMATCH` | D 最新版把 Closed Shape 从 Warning 改为 Violation，需冻结最终版本 |
| 被验证 metadata = 实际发布 metadata | 未提供发布 metadata hash | 无 | current demo 文件不同 | PDF 未绑定输入 hash | `NOT_PROVEN` | 目前只能声明“D 样例通过” |

## Shapes 哈希差异的实质

C 组 `model-version.json` 登记的 D profile 哈希为：

`A556039C0EC3030A9C4273C62A787E448B8869F7648E948663E10D3FE007CBDA`

D 组最新 `To_B` 文件哈希为：

`17DACE38CB949796D3BDEF0D5BA3002763A5FAC84FF56650F886CDCF8E6AE53D`

内容差异集中在 Closed Shape：C 登记版使用 `sh:Warning`，D 最新交付使用 `sh:Violation`，并明确把额外属性映射为 `INAPPLICABLE` 后拒绝。因此两者不能视作同一规则文件。

## 当前可追溯结论

可以证明：D 的 valid 样例通过 D 最新报告所声明的 v1.1 profile 流程；invalid 样例被正确拒绝。

不能证明：D 验证的字节级输入就是 A 组实际发布 metadata，或 D 报告使用的 Shapes 字节就是当前 `To_B` 中的 `17DACE...` 文件。PDF 内没有输入/规则哈希，关联关系来自 D 组 README 的人工声明。

