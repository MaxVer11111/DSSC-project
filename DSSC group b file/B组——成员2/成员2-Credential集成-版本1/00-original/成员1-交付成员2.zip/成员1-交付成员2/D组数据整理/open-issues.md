# 交付成员 2：未解决问题

## P0：生成或重新签名 Credential 前必须解决

### P0-1 Provider ID 不一致

- A 组：`did:web:mp-operations.org`
- B 组旧 LegalPerson：`energy-provider.example.org` 相关占位身份
- D 组：只提供 Provider name，没有 Provider ID

行动：由 A/B 确认唯一 Provider DID，并同步到 `LegalPerson.credentialSubject.id` 与 `ServiceOffering.providedBy`。内容变化后重新签名。

### P0-2 Offering ID 尚未冻结

A 组候选值为 `urn:dssc:service-offering:building-energy-hourly-v1`，但状态仍是 `proposed-pending-ab-confirmation`。

行动：A/B 确认后再写入 ServiceOffering subject ID。

### P0-3 Dataset URI 冲突

- A/C：`urn:dssc:dataset:building-energy-hourly-v1`
- D：`https://example.org/dssc-energy/datasets/building-energy-hourly-v1`

行动：冻结 canonical URI；若改用 A/C URI，需要用该最终 metadata 重新执行 D 验证。

### P0-4 Endpoint 与 Format 冲突

- A/C Endpoint：本地 Scorpio/NGSI-LD Endpoint
- D Endpoint：`https://api.example.org/energy/buildings/hourly`
- A 格式：`application/ld+json`
- C 格式：`JSON`
- D 格式：`application/json`

行动：以实际 Connector 响应为准统一 Endpoint 和 MIME type，并让 D 组重新验证最终 metadata。

### P0-5 D Shapes 版本未冻结

C 登记哈希 `A556039C...` 与 D 最新交付 `17DACE38...` 不同；Closed Shape 严重级别已从 Warning 变为 Violation。

行动：C/D 共同确认最终规则文件、profile 版本和哈希；最终报告必须引用同一哈希。

## P1：正式、可复现、可审计交付前补齐

1. Validator 的正式名称、版本和 Endpoint。
2. 报告时间所使用的时区。
3. 原始 SHACL 报告（TTL/JSON 等）。
4. ITB 原始机器可读结果。
5. 上传文件、Shapes 文件及其 SHA-256 的请求记录。
6. Validator 请求/响应或操作截图。
7. Authority 许可证白名单文件、版本和哈希。
8. A 组实际发布 metadata 的文件和哈希。
9. D 报告与具体输入文件的不可抵赖绑定；当前 PDF 只显示 `[File content]`。

## P2：展示质量问题

`valid_TC02.pdf` 第 4 页的 Step 3 标题在原 PDF 左侧出现裁切，但“许可证位于 Authority whitelist”的结论仍可阅读。建议 D 组最终导出时修正页面布局。

## 可在问题解决前继续的工作

- 使用已一致的 Dataset ID、Provider name、标题、License、频率、单位和时空范围制作未签名草稿。
- 整理 Valid/Invalid evidence manifest。
- 准备负向测试流程。
- 不生成或不宣称新的正式 signed VP-JWT。

