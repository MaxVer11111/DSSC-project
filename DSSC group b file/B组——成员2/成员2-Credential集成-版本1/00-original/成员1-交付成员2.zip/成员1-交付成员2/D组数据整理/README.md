# D 组数据交付给成员 2：使用说明

## 结论先行

D 组材料已经完成完整性核验，7 个业务文件的实际 SHA-256 与 D 组 README 完全一致。四份 ITB PDF 报告也已逐页核对：

- valid metadata 的 TC01 字段验证：`SUCCESS`
- valid metadata 的 TC02 许可证策略验证：`SUCCESS`
- invalid metadata 的 TC01：`FAILURE`，准确识别 3 个字段错误
- invalid metadata 的 TC02：`FAILURE`，准确识别许可证数量为 0

但这些材料当前只证明 **D 组样例 metadata** 通过了指定规则，尚不能证明 A 组实际发布的 metadata 已经通过同一验证。D 组样例中的 Dataset URI、Endpoint 和 Format 与 A/C 组当前 demo 不一致，因此成员 2 不应直接把这些冲突值签入 ServiceOffering Credential。

当前交付状态：`PARTIAL_DO_NOT_SIGN_UNTIL_P0_RESOLVED`。

## 成员 2 可以直接使用的内容

以下字段已在 A/C/D 之间取得一致或具有明确依据：

| 字段 | 建议值 | 用途 |
|---|---|---|
| Dataset ID | `building-energy-hourly-v1` | ServiceOffering 对 Dataset 的引用 |
| Provider name | `Energy Data Provider Ltd.` | 与 LegalPerson 名称核对 |
| Offering title | `Building Energy Consumption Dataset API` | ServiceOffering 名称 |
| License | `https://creativecommons.org/licenses/by/4.0/` | ServiceOffering 条款/许可证引用 |
| Frequency | `hourly` | Dataset metadata 证据，不必强行写入 Credential |
| Unit | `kWh` | Dataset metadata 证据 |
| Temporal range | `2026-05-01` 至 `2026-05-02` | Dataset metadata 证据 |
| Spatial coverage | `Shenzhen demo district` | Dataset metadata 证据 |

## 签名或生成 VP-JWT 前必须解决

1. Provider ID：A 组当前为 `did:web:mp-operations.org`，B 组旧 LegalPerson 仍使用 `energy-provider.example.org` 占位身份。
2. Offering ID：A 组值仍标记为 `proposed-pending-ab-confirmation`。
3. Dataset URI：D 组使用 `https://example.org/...`，A/C 组使用 `urn:dssc:dataset:building-energy-hourly-v1`。
4. Endpoint：D 组为示例 API；A/C 组为本地 FIWARE/Scorpio Endpoint。
5. Format：D 组固定为 `application/json`，A 组实际响应为 `application/ld+json`，C 组写作 `JSON`。
6. D Shapes 版本：D 最新交付哈希与 C 组 `model-version.json` 登记哈希不同，差异会改变 Closed Shape 的处理结果。

详细情况见 [consistency-matrix.md](consistency-matrix.md) 和 [open-issues.md](open-issues.md)。

## 推荐使用顺序

1. 打开 `service-offering-input-from-d.json`，读取已确认字段和冲突字段。
2. 先解决 `open-issues.md` 中的 P0 项，再更新 LegalPerson 和 ServiceOffering。
3. 以 A 组冻结后的 Provider ID、Offering ID、Dataset URI、Endpoint 和真实响应格式为身份及部署基线。
4. 使用 D 组 valid metadata 中已与 A/C 对齐的字段补充 Dataset/ServiceOffering 描述。
5. 将 `valid_TC01.pdf` 和 `valid_TC02.pdf` 作为独立的 metadata conformance evidence，不要当成 Gaia-X Compliance Credential。
6. 将两份 Invalid 报告仅用于负向测试和拒绝路径。
7. Credential 内容发生变化后重新签名，不要复用旧 JWT。

## 文件说明

| 文件 | 内容 |
|---|---|
| `d-group-input-register.md` | D 组原始交付登记与哈希核验 |
| `service-offering-input-from-d.json` | 提供给成员 2 的结构化字段输入 |
| `d-validation-summary.json` | 四个测试报告的机器可读人工摘要 |
| `d-to-credential-mapping.md` | D 字段到 Credential/证据包的使用映射 |
| `consistency-matrix.md` | A/B/C/D 关键字段一致性检查 |
| `open-issues.md` | 签名前必须解决及证据质量问题 |
| `SHA256SUMS.txt` | 本交付包文件哈希 |
| `source/To_B.zip` | D 组原始压缩包副本 |
| `source/To_B/` | D 组原始交付解压副本 |

## 验证边界

本交付只确认：D 组提交的样例、规则和 PDF 报告内部结果一致，并对跨组字段进行了核对。

本交付不声称：

- A 组实际发布文件已由 D 组验证；
- Provider、ServiceOffering 或 VP-JWT 已通过 Gaia-X compliance；
- D 组 Validator 版本、Endpoint、许可证白名单版本已可审计；
- PDF 内 `[File content]` 能独立证明上传文件的名称或哈希。

