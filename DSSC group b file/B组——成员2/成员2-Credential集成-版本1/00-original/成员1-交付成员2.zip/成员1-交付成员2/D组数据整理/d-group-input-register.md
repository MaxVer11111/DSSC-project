# D 组输入登记与完整性核验

## 来源

- 原始目录：`DSSC group b file/跨组对接清单/To_B/`
- 原始压缩包：`DSSC group b file/跨组对接清单/To_B.zip`
- 压缩包 SHA-256：`78837883F063F2F88C714002FD3F43009CA0505620236B80CC0F32C18B6B8EE7`
- 整理日期：2026-08-12（Asia/Shanghai）
- 整理角色：B 组成员 1
- 原始材料处理原则：只读核验；交付包内保存副本，不修改 D 组原文件

## 文件登记

| 相对路径 | 字节数 | SHA-256 | 用途 | 核验 |
|---|---:|---|---|---|
| `README.md` | 9264 | `BF63C76AFA6108131C9EAE35D9FF168EF1ECBF01D2962A2ACEC192F094B1FE70` | D 组交付说明和哈希清单 | 已读取 |
| `metadata/data-product-valid.jsonld` | 1457 | `045A44A3180F3781579F95B762E25C25F32A34EAD418D1863800BFBDF4728B10` | 正向 metadata 样例 | JSON 语法通过；关键字段已提取 |
| `metadata/data-product-invalid.jsonld` | 1305 | `0ADE622953414C5F53FDC40300972C6D47C6EA6FDF28E12071F7EA6EB86F7BD2` | 负向 metadata 样例 | JSON 语法通过；仅用于测试 |
| `shacl-rules/building-energy-shapes_D.ttl` | 10790 | `17DACE38CB949796D3BDEF0D5BA3002763A5FAC84FF56650F886CDCF8E6AE53D` | D 组最终 SHACL Shapes | 已读取并与 C 组登记版比较 |
| `validation-reports/valid_TC01.pdf` | 25771 | `1B5D98E4380FEF330ACB8DE5FBE15144BF94269CEB5C947383AF87A78C33E767` | Valid 字段验证报告 | 4 页逐页核对 |
| `validation-reports/valid_TC02.pdf` | 33135 | `DEBAE9C0D834D4284AE277F502021F93D57F4986825231623FCFA51145FD35A9` | Valid 许可证策略报告 | 5 页逐页核对 |
| `validation-reports/Invalid_TC01.pdf` | 30581 | `1EFC9CC791DD49E6D27574300809F1E45AA861304F5045A8E145F0ACC88FF7B4` | Invalid 字段验证报告 | 4 页逐页核对 |
| `validation-reports/Invalid_TC02.pdf` | 28252 | `F00A328DB7F10F40564CB76D2BEC24C56FE50C3750D8631B46E26DFF3AA22A8F` | Invalid 许可证策略报告 | 4 页逐页核对 |

## 完整性结论

- README 列出的 7 个业务文件全部存在。
- 7 个业务文件的实际 SHA-256 均与 README 一致。
- 两份 JSON-LD 均可由标准 JSON 解析器读取。
- Shapes 文件内容完整，包含 Dataset 数量、必填字段、枚举值、HTTPS Endpoint、日期顺序及 Closed Shape 等规则。
- 四份 PDF 均可打开、渲染和逐页阅读。

## 仍缺少的原始证据

- Validator 名称的正式产品/服务标识、版本和 Endpoint
- 原始机器可读 SHACL 报告
- ITB 原始 JSON 等机器可读结果
- Validator 请求和响应
- 上传输入的文件名与哈希记录
- 许可证 Authority 白名单原文件及版本
- 明确时区

