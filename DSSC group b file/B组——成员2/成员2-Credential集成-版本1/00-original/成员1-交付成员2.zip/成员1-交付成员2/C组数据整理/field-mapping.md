# C 组数据到 B 组 Credential / Evidence 字段映射

本文件供成员 2 制作当前演示用 `LegalPerson`、`ServiceOffering` Credential 及配套 evidence。A 组实值来自同级目录外的 `B组-A组Demo交接包/a-to-b-data-summary.json`。

## 一、成员 2 可使用的映射

| 数据 | 当前 Demo 值 | 成员 2 使用位置 | 状态 |
|---|---|---|---|
| Provider ID | `did:web:mp-operations.org` | `LegalPerson.credentialSubject.id`；`ServiceOffering.gx:providedBy` | A 组提供；当前 Demo 使用 |
| Provider name | `Energy Data Provider Ltd.` | LegalPerson 名称字段 | A/C 一致 |
| Canonical Service Offering ID | `urn:dssc:service-offering:building-energy-hourly-v1` | `ServiceOffering.credentialSubject.id` | A 组提案；当前 Demo 使用，待 A/B 最终确认 |
| Dataset ID | `building-energy-hourly-v1` | 核对 C metadata、A Offering 和后续 D 报告是否为同一 Dataset | A/C 一致 |
| Dataset URI | `urn:dssc:dataset:building-energy-hourly-v1` | `ServiceOffering.gx:aggregationOf` 的引用对象 | A 组提案；当前 Demo 使用，待 A/B 最终确认 |
| Endpoint | `https://scorpio-provider.127.0.0.1.nip.io/ngsi-ld/v1/entities/urn:ngsi-ld:Building:BLD-001` | ServiceOffering 服务访问描述或技术附件 | A 组 Real Cluster 实值；本机可访问 |
| HTTP method | `GET` | ServiceOffering 技术说明 | A 组实值 |
| 序列化类别 | `JSON` | C 组 Dataset metadata 的 `format` | C v0.3 约束值 |
| HTTP media type | `application/ld+json` | ServiceOffering 数据访问/响应格式 | A 组 Real Cluster 实值 |
| License URL | `https://creativecommons.org/licenses/by/4.0/` | ServiceOffering license/terms 对应字段 | A 组提供；C v0.3 核心模型不定义此字段 |
| Semantic model ID | `https://w3id.org/dssc-demo/building-energy/v0.3` | Evidence manifest 或 Credential 配套说明 | C 组可用 |
| Semantic model version | `v0.3` | Evidence manifest | C 组可用；必须同时标注 `draft` |
| Namespace | `https://w3id.org/dssc-demo/building-energy#` | 字段语义解释 | C 组可用 |

## 二、只保留在 Dataset metadata

| C 组字段 | 当前值 | 成员 2 处理 |
|---|---|---|
| `frequency` | `hourly` | 不写入 LegalPerson；默认不写入 ServiceOffering Credential |
| `unit` | `kWh` | 保留在 Dataset / Energy Reading Record |
| `spatialCoverage` | `Shenzhen demo district` | 保留在 Dataset metadata |
| `temporalStart` | `2026-05-01` | 保留在 Dataset metadata |
| `temporalEnd` | `2026-05-02` | 保留在 Dataset metadata |

这些值来自 C 组演示样例；成员 2 不负责把它们解释成生产数据范围。

## 三、格式字段的处理规则

下面两个值描述的层次不同，必须同时保留：

```text
C 组 metadata format = JSON
A 组 HTTP response media type = application/ld+json
```

- `JSON` 是 C v0.3 SHACL 当前允许的序列化类别字面量。
- `application/ld+json` 是 A 组 Scorpio 实际接口的 HTTP media type。
- 不要把 `application/ld+json` 直接写入 C 组 `format` 字段后再宣称通过现有 C v0.3 SHACL；该 shape 当前只接受字面量 `JSON`。
- ServiceOffering 的技术访问格式应优先记录实际 media type `application/ld+json`。

## 四、Endpoint 的处理规则

C 组原始正例中的：

```text
https://api.example.org/energy/buildings/hourly
```

是目标业务接口示例，不是当前已部署地址。本轮 Demo 使用 A 组 Real Cluster endpoint：

```text
https://scorpio-provider.127.0.0.1.nip.io/ngsi-ld/v1/entities/urn:ngsi-ld:Building:BLD-001
```

该地址仅适用于本地演示环境，成员 2 应在 Credential 配套说明中标注 `local-real-cluster / publiclyReachable=false`。

## 五、不要混淆的标识

```text
LegalPerson subject / providedBy
= did:web:mp-operations.org

ServiceOffering subject
= urn:dssc:service-offering:building-energy-hourly-v1

aggregationOf
= urn:dssc:dataset:building-energy-hourly-v1

具体 Scorpio Resource
= urn:ngsi-ld:Building:BLD-001
```

TMForum ProductOffering 实例 ID 只作为 A 组发布证据，不应写成稳定的 ServiceOffering subject。

## 六、成员 2 生成前检查

- `LegalPerson.credentialSubject.id` 与 `ServiceOffering.gx:providedBy` 相同。
- `ServiceOffering.credentialSubject.id` 使用 Canonical Offering ID，而不是 TMForum ProductOffering UUID。
- `gx:aggregationOf` 使用 Dataset URI，而不是普通 `datasetId` 字符串或 Scorpio Resource ID。
- 不使用 C 组 `example.org` endpoint 作为已部署地址。
- 同时记录 C 模型版本 `v0.3` 和状态 `draft`。
- C 组 Dataset-only 字段不被强行写入 Credential。
- Credential 内容变化后重新签名。

