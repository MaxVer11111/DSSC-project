# A 组实值与 C 组语义数据一致性矩阵

| 对齐项 | A 组当前 Demo 值 | C 组值 | 结论 | 成员 2 使用规则 |
|---|---|---|---|---|
| Provider name | `Energy Data Provider Ltd.` | `Energy Data Provider Ltd.` | `MATCH` | 可用于 LegalPerson 名称 |
| Provider ID/DID | `did:web:mp-operations.org` | C 组未定义 | `SUPPLIED_BY_A` | 当前 Demo 用于 LegalPerson subject / providedBy |
| Dataset ID | `building-energy-hourly-v1` | `building-energy-hourly-v1` | `MATCH` | 用作跨组稳定核对键 |
| Dataset URI | `urn:dssc:dataset:building-energy-hourly-v1` | C 原始正例使用 HTTP Data Product `@id` | `NORMALIZED_FOR_DEMO` | 当前 Demo 按 A 组提案 URI 引用；待 A/B 最终确认 |
| Canonical Offering ID | `urn:dssc:service-offering:building-energy-hourly-v1` | C 模型不定义 Offering ID | `SUPPLIED_BY_A` | 当前 Demo 使用；待 A/B 最终确认 |
| Endpoint | Scorpio 本地 NGSI-LD entity endpoint | `https://api.example.org/energy/buildings/hourly` | `C_SAMPLE_REPLACED_IN_NORMALIZED_COPY` | Credential/技术附件使用 A 组 endpoint；C 原件保持不变 |
| Format | HTTP media type `application/ld+json` | metadata 字面量 `JSON` | `COMPATIBLE_IF_SEPARATED` | 分别记录 media type 与序列化类别，不互相覆盖 |
| License | CC BY 4.0 URL | C v0.3 核心模型未定义；D profile 示例包含相同 URL | `SUPPLIED_BY_A` | ServiceOffering 条款使用 A 组值 |
| Frequency | A 组摘要未单列 | `hourly` | `C_DATASET_ONLY` | 只保留在 Dataset metadata |
| Unit | A 组场景为能耗数据 | `kWh` | `C_DATASET_ONLY` | 只保留在 Dataset/记录层 |
| Spatial coverage | 描述为 Shenzhen buildings | `Shenzhen demo district` | `DEMO_LEVEL_COMPATIBLE` | 保留 C 样例值，不作为法律/生产范围 |
| Semantic model version | A 组交接包未声明 | `v0.3` | `SUPPLIED_BY_C` | Evidence 中记录 `v0.3 / draft` |
| D 组验证对象和 hash | 尚未提供 | C 提供 shapes 和样例 | `PENDING_D` | 收到 D 组报告后再完成最终 onboarding evidence 对齐 |

## 当前可交接结论

成员 2 可以开始制作 Demo Credential 草稿。以下两个稳定 URI 仍带 A 组的 `proposed-pending-ab-confirmation` 状态：

- `urn:dssc:service-offering:building-energy-hourly-v1`
- `urn:dssc:dataset:building-energy-hourly-v1`

它们可用于本轮 Demo，但在宣称“最终冻结并签名”前，应由 A/B 组确认。

