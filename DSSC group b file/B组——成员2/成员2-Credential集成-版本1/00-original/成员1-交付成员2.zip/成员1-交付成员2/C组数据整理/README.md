# B 组成员 1 向成员 2 的 C 组数据交接包

本目录将 C 组 Building Energy Semantic Model v0.3 与 A 组当前 Real Cluster Demo 实值完成对齐，供成员 2 制作 `LegalPerson`、`ServiceOffering` Credential 及其配套 evidence。

## 使用顺序

1. 阅读 `c-to-b-data-summary.json`，获取 C 组模型基线和已与 A 组对齐的 Demo 值。
2. 按 `field-mapping.md` 更新 Credential 或 evidence；不要把 Dataset-only 字段强行写入 Credential。
3. 查看 `a-c-consistency-matrix.md`，了解哪些值已匹配、哪些来自 A 组、哪些仍需 D 组确认。
4. 使用 `current-demo-metadata.jsonld` 作为成员 1 整理后的本轮 Demo metadata 输入。
5. 阅读 `demo-notes.md`，保留模型状态、本地 endpoint 和格式表示等限制说明。
6. 如需追溯 C 组原件，按 `source-register.md` 中的路径读取，不要修改原始对接包。

## 目录内容

```text
B组-C组Demo交接包/
├── README.md
├── c-to-b-data-summary.json
├── field-mapping.md
├── a-c-consistency-matrix.md
├── current-demo-metadata.jsonld
├── demo-notes.md
├── source-register.md
└── SHA256SUMS.txt
```

## 成员 1 交接结论

- `datasetId` 和 `providerName` 已与 A 组当前 Demo 基线匹配。
- Provider DID、Dataset URI、实际 endpoint、HTTP media type 和 License 已从 A 组交接包补齐。
- C 组 `example.org` endpoint 仅保留为原始样例，不再作为本轮已部署 endpoint。
- C 组 `format = JSON` 与 A 组 `application/ld+json` 已分成“序列化类别”和“HTTP media type”记录。
- C 组模型仍为 `draft / Research demo release candidate`。
- C 组原始文件及 ZIP 均保持不变；成员 1 生成的 normalized metadata 与 C 组原件明确分开。
- D 组实际验证文件、报告和 metadata hash 尚未纳入本包，后续由成员 1 在 D 组交付到达后继续核对。

`SHA256SUMS.txt` 用于核对本次交接快照；该清单不包含其自身。

