# D 组最终 metadata 验证层

## 基线

- Shape：`metadata-shapes-D-final.ttl`
- SHA-256：`A556039C0EC3030A9C4273C62A787E448B8869F7648E948663E10D3FE007CBDA`
- 来源：用户指定的微信文件 `building-energy-shapes_D(1).ttl`
- 核对结果：与整理前项目根目录中的同名文件逐字一致
- 目标数据：原项目扁平结构、类型为 `dcat:Dataset` 的 metadata

## 配套文件

| 文件 | 用途 |
|---|---|
| `context-D.jsonld` | D profile 对应的独立 context |
| `data-product-valid-D.jsonld` | 应通过 D profile 的原 metadata 示例 |
| `data-product-invalid-D.jsonld` | 应被 D profile 拒绝的原 metadata 示例 |

## 主要约束

- 提交图中必须恰好存在一个 `dcat:Dataset`。
- 必填字段均限制为一个值；字符串不可为空白。
- `frequency = hourly`、`unit = kWh`、`format = application/json`。
- Endpoint 必须是 HTTPS IRI。
- `temporalStart` 不得晚于 `temporalEnd`。
- `description` 和 `license` 可选；`license` 如提供必须是 HTTPS IRI。
- 未声明属性由 closed shape 以 Warning 标记，供 ITB 映射为 `INAPPLICABLE`。

该文件是原 metadata 的验证层；C 组 v0.3 语义模型仍使用交付包顶层的 `be:` namespace 和对应工件。
