# 交付包验证结果

验证日期：2026-08-10

| 检查 | 结果 |
|---|---|
| 13 个 JSON / JSON-LD 文件语法解析 | PASS |
| `semantic-model.jsonld` RDF 解析 | PASS，8 triples |
| `vocabulary.ttl` RDF 解析 | PASS，101 triples |
| C v0.3 metadata SHACL 解析 | PASS，62 triples |
| Energy Reading Record SHACL 解析 | PASS，40 triples |
| D 最终 SHACL 解析 | PASS，179 triples |
| C v0.3 metadata valid 示例 | PASS |
| C v0.3 metadata invalid 示例 | 按预期 FAIL |
| Energy Reading Record valid 示例 | PASS |
| Energy Reading Record invalid 示例 | 按预期 FAIL |
| D profile 原 metadata valid 示例 | PASS |
| D profile 原 metadata invalid 示例 | 按预期 FAIL |
| Energy Reading Record JSON Schema valid 示例 | PASS，0 errors |
| Energy Reading Record JSON Schema invalid 示例 | 按预期 FAIL，3 errors |
| C 组工程 `make validate` | PASS |

正例和反例结果均符合预期。
