# 给 B 组的发送说明

B 组你好，C 组已按数据清单整理好 Building Energy Semantic Model 对接包，附件为 `B组-C组对接包_2026-08-10.zip`。

请按以下信息引用：

- Semantic model：`https://w3id.org/dssc-demo/building-energy/v0.3`
- Namespace：`https://w3id.org/dssc-demo/building-energy#`
- Version：`v0.3`
- Context：`context.jsonld`
- C 组 metadata SHACL：`metadata-shapes.ttl`
- D 组原 metadata 最终验证规则：`d-validation-profile/metadata-shapes-D-final.ttl`

包内已经包含字段定义、B 组映射表、正反例、版本记录、provenance、Semantic Treehouse 证据和 SHA-256 清单。

请 B 组结合实际 credential 确认 LegalPerson 正式名称；Dataset ID 和 endpoint 仍需与 A 组实际发布值对齐。`license` 是 D profile 的可选字段，不属于 C 组 v0.3 核心字段。
