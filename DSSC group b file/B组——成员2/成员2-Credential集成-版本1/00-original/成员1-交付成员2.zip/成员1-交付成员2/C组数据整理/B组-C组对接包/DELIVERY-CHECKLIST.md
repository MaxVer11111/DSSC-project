# 交付核对

## 已提供

- [x] 模型名称、模型 ID、namespace、版本、发布日期、状态和负责人
- [x] C 组 v0.3 JSON-LD context
- [x] C 组 v0.3 RDF/TTL ontology
- [x] C 组 v0.3 metadata SHACL
- [x] Data Product Metadata 字段 URI、定义、类型、基数、约束和示例
- [x] Energy Reading Record 字段定义及相关工件
- [x] C 组 v0.3 valid/invalid metadata 示例
- [x] 版本变更记录和 provenance
- [x] Semantic Treehouse 本地部署记录与 smoke-check 证据
- [x] D 组最终 metadata 验证规则及原 metadata 正反例
- [x] Dataset metadata 到 B 组内容的映射说明
- [x] SHA-256 完整性清单

## 一致性结果

- [x] 顶层 C v0.3 context、ontology、SHACL 和正反例使用同一模型版本与 namespace
- [x] D 组最终 shape 与原项目扁平 metadata 配套存放，没有冒充 C v0.3 shape
- [x] `license` 的范围已明确：D profile 可选字段，不是 C v0.3 核心字段
- [x] B 组可映射字段与应保留在 Dataset metadata 的字段已分开列出

## 仍需 A/B 组填入或确认

- [ ] A 组实际发布的 Dataset ID
- [ ] B 组 LegalPerson 的正式名称
- [ ] A 组实际 OpenAPI / Connector endpoint
- [ ] 数据提供方最终 licence URL
- [ ] B 组生成 credential 时记录模型版本 `v0.3`

这些项目涉及其他组的实际发布值，交付包没有用示例值替代正式值。
