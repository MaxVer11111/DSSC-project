# B 组字段映射确认

| Dataset metadata | B 组对应内容 | 确认结果 |
|---|---|---|
| `datasetId` | `gx:aggregationOf` 引用对象 | 可采用。`gx:aggregationOf` 应引用 Dataset 对象的 `@id`；再用该对象的 `datasetId` 核对业务标识，不应把普通字符串直接当对象引用。 |
| `providerName` | LegalPerson name / `gx:providedBy` 所指主体 | 可采用。`providerName` 用于名称一致性核对，`gx:providedBy` 保留为对 LegalPerson 主体的引用。 |
| `endpointUrl` | ServiceOffering 服务访问描述 | 可采用。其值应与 A 组实际 OpenAPI/Connector endpoint 一致。 |
| `format` | `gx:dataAccountExport.gx:formatType` 或等效字段 | 可作为格式对应项；C v0.3 值为 `JSON`，D profile 原 metadata 值为 `application/json`。 |
| `license` | `gx:termsAndConditions.gx:URL` 或等效字段 | 可作为条款 URL 对应项。该字段只在 D profile 中定义为可选 `dct:license`，C v0.3 核心模型没有此字段。 |
| `frequency` | 关联 Dataset metadata | 确认保留在 Dataset metadata。 |
| `unit` | 关联 Dataset metadata | 确认保留在 Dataset metadata。 |
| `spatialCoverage` | 关联 Dataset metadata | 确认保留在 Dataset metadata。 |
| `temporalStart` / `temporalEnd` | 关联 Dataset metadata | 确认保留在 Dataset metadata。 |

## B 组记录内容

- Semantic model：`https://w3id.org/dssc-demo/building-energy/v0.3`
- Namespace：`https://w3id.org/dssc-demo/building-energy#`
- Model version：`v0.3`
- Context：`context.jsonld`
- C 组 metadata shape：`metadata-shapes.ttl`
- D 组原 metadata 验证 shape：`d-validation-profile/metadata-shapes-D-final.ttl`

## 尚需填入的跨组实值

| 对齐项 | 当前示例值 | 最终值来源 |
|---|---|---|
| Dataset ID | `building-energy-hourly-v1` | A/C 组共同确认 |
| Provider name | `Energy Data Provider Ltd.` | B 组 LegalPerson 实际名称 |
| Endpoint | `https://api.example.org/energy/buildings/hourly` | A 组实际发布地址 |
| Licence URL | `https://creativecommons.org/licenses/by/4.0/` | 数据提供方/条款文件 |
