﻿# Semantic Treehouse Local Deployment Evidence

## Environment

- Host OS: Windows / PowerShell evidence harness
- Docker: Docker version 29.5.2, build 79eb04c
- Docker Compose: Docker Compose version v5.1.4

## Docker Version

~~~text
Docker version 29.5.2, build 79eb04c
Docker Compose version v5.1.4
~~~

## Upstream Commit

~~~text
33cf285c187f58c773f4e0d8c2826eeb2f6b3778
~~~

## Commands Run

- git clone or git fetch through make treehouse-clone
- docker volume create sth-app-data
- docker volume create sth-db2-data
- copy .env.example to .env if .env is missing
- docker compose -p dssc_treehouse_evidence --project-directory <upstream> --env-file <upstream>/.env -f <compose-file> --profile dev up -d --build through make treehouse-up
- docker compose ... exec -T --workdir /app backend-dev composer install --no-interaction
- docker compose ... exec -T --workdir /app backend-dev php bin/console doctrine:migrations:migrate --no-interaction
- docker compose ps / docker ps through status capture

Selected compose file:

~~~text
C:\Users\12491\Desktop\CUHKSZ\TIDE\DSSC\tools\semantic-treehouse\upstream\docker-compose.yml
~~~

## Result

SUCCESS: Docker Compose command and upstream post-start setup completed. Inspect container status and smoke check for UI/API availability.

## UI/API URLs Checked

~~~text
Smoke check: http://localhost:4200/
curl exit code: 0
HTTP/1.1 200 OK
Vary: Origin
Content-Type: text/html
Cache-Control: no-cache
Date: Thu, 25 Jun 2026 11:35:01 GMT
Connection: keep-alive
Keep-Alive: timeout=5
---
Smoke check: http://localhost:8014/
curl exit code: 28
curl: (28) Operation timed out after 5009 milliseconds with 0 bytes received
~~~

## Screenshots To Capture Manually

- Semantic Treehouse home page if a UI port is available.
- Specification or vocabulary list if accessible.
- API or documentation route if exposed by the upstream deployment.

## Errors And Interpretation

~~~text
No fatal deployment command error captured.
composer install exit code: 0
phpstan/extension-installer: Extensions installed

Installing dependencies from lock file (including require-dev)
 
Verifying lock file contents can be installed on current platform.
Nothing to install, update or remove
Package spatie/data-transfer-object is abandoned, you should avoid using it. Use spatie/laravel-data instead.
Generating autoload files
134 packages you are using are looking for funding.
Use the `composer fund` command to find out more!

Run composer recipes at any time to see the status of your Symfony recipes.
doctrine migrations exit code: 0
[OK] Already at the latest version ("DoctrineMigrations\Version20260522133345")

Smoke interpretation: the documented Semantic Treehouse development UI at http://localhost:4200/ responded successfully. The backend/root port at http://localhost:8014/ is mapped by Compose, but the root HEAD smoke check did not return within the 5 second timeout. This is evidence-track information only and does not affect independent semantic validation.
~~~

## Impact On C Group Deliverables

Semantic Treehouse local deployment is supporting evidence only. Failure does not block the semantic governance package because the RDF, JSON-LD, SHACL, JSON Schema, OpenAPI, SPARQL, quality, and governance validations run independently.

## Fallback Validation Path

Run:

~~~bat
cmd /c make validate
~~~
