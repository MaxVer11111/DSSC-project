# Model Card

## Model Name

Building Energy Semantic Model

## Scope

This model governs the shared semantics for the Building Energy Consumption Data Product. It covers two layers:

- Data Product Metadata for catalogue, connector offering, and SHACL validation.
- Energy Reading Record for API payload, JSON Schema, OpenAPI, and optional SHACL validation.

## Intended Users

- C Group: semantic model owners and maintainers.
- A Group: connector and data offering implementers.
- D Group: SHACL/ITB validation designers.
- B Group: optional Gaia-X service offering or credential authors.
- Data Space Authority: reviewer and approver of semantic releases.

## Intended Use

- Define a compact, standards-aligned semantic contract for the demo data product.
- Publish versioned artifacts for metadata validation and API payload alignment.
- Provide reusable mappings to DCAT/DCTERMS, SOSA/SSN, QUDT/UCUM, OWL-Time, and schema.org patterns.

## Out-of-Scope Use

- Production energy market settlement.
- Legal compliance certification.
- Full building information modeling.
- Full geospatial or temporal reasoning.
- Replacement for connector, compliance, or ITB tooling.

## Standards Reused

- DCAT/DCAT-AP pattern for dataset and service metadata.
- DCTERMS for identifiers, format, spatial metadata, and conformance links.
- SOSA/SSN for observation and sensor alignment.
- QUDT/UCUM pattern for energy units.
- OWL-Time/XSD dates for temporal coverage.
- SHACL for RDF validation.
- JSON-LD for serializing linked metadata.
- JSON Schema and OpenAPI for API payload integration.
- SSSOM for semantic mapping documentation.
- PROV-O-inspired metadata for model provenance.

## Validation Strategy

- RDF/Turtle syntax validation with `rdflib`.
- JSON-LD expansion with `pyld`.
- SHACL valid/invalid cases with `pyshacl`.
- JSON Schema valid/invalid record validation.
- OpenAPI structure validation.
- SPARQL competency questions.
- Quality metrics for coverage, constraint strength, reuse ratio, and breaking-change risk.
- Governance/provenance validation.

## Risks

- The unit field is currently a literal `kWh`, not a QUDT URI.
- Provider and location are lightweight strings/objects rather than full organization/place resources.
- Temporal coverage is represented by dates rather than a full OWL-Time interval.
- Mapping confidence varies by field and must be reviewed before production reuse.

## Maintenance Owner

City Energy Data Space Authority, represented by DSSC C Group for this research package.

## Review Status

Research demo release candidate. Automated checks are required before any handoff to A Group or D Group.
