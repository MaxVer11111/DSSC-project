# B 组—C 组语义模型对接包

## 模型信息

| 项目 | 值 |
|---|---|
| 模型名称 | Building Energy Semantic Model |
| 模型 ID | `https://w3id.org/dssc-demo/building-energy/v0.3` |
| 命名空间 | `https://w3id.org/dssc-demo/building-energy#` |
| 前缀 | `be` |
| 版本 | `v0.3` |
| 发布日期 | `2026-06-25` |
| 状态 | Draft；评审状态为 Research demo release candidate |
| 负责人 | City Energy Data Space Authority（本研究包由 DSSC C 组维护） |

## 文件清单

| 文件 | 内容 |
|---|---|
| `semantic-model.jsonld` | 模型 ID、版本和发布信息 |
| `model-version.json` | 机器可读版本信息及文件 SHA-256 |
| `context.jsonld` | C 组 v0.3 Data Product Metadata context |
| `vocabulary.ttl` | C 组 v0.3 ontology |
| `metadata-shapes.ttl` | C 组 v0.3 metadata SHACL |
| `field-definition.md` | Data Product Metadata 与 Energy Reading Record 字段定义 |
| `field-mapping-to-B.md` | Dataset metadata 与 B 组 ServiceOffering/LegalPerson 的对应关系 |
| `data-product-valid.jsonld` | C 组 v0.3 有效 metadata 示例 |
| `data-product-invalid.jsonld` | C 组 v0.3 无效 metadata 示例 |
| `energy-reading-record/` | 记录层 context、SHACL、Schema、OpenAPI 和正反例 |
| `d-validation-profile/` | D 组最终规则及原 metadata 正反例 |
| `governance/` | 模型卡、变更记录、namespace 政策和 provenance |
| `evidence/` | Semantic Treehouse 部署记录和自动验证报告 |
| `DELIVERY-CHECKLIST.md` | 本次交付完成项及仍需 A/B 组确认的实值 |
| `SHA256SUMS.txt` | 交付文件完整性校验值 |

## 两层文件的边界

- C 组 v0.3 是 B 组引用的语义模型，使用 `be:` namespace。顶层 `context.jsonld`、`vocabulary.ttl`、`metadata-shapes.ttl` 和 v0.3 正反例相互一致。
- `d-validation-profile/metadata-shapes-D-final.ttl` 是对原项目扁平 metadata 的最终验证规则，使用 `ex:`、`dct:` 和 `dcat:` 路径。它保留为单独的验证层，不作为 C 组 v0.3 namespace 的替代品。
- `license` 不属于 C 组 v0.3 核心字段；它只在 D 组最终验证层中以 `dct:license` 作为可选 HTTPS IRI。

## 交付方式

直接发送同级目录中的 `B组-C组对接包_2026-08-10.zip`。B 组引用模型时使用上表中的 v0.3 模型 ID；D 组验证原 metadata 时使用 `d-validation-profile/metadata-shapes-D-final.ttl`。
