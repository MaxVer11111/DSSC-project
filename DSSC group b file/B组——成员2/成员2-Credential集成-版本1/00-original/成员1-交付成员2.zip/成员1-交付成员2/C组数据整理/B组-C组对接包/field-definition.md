# 字段定义

## Data Product Metadata（C 组 v0.3）

| 字段 | 完整 URI | 中英文定义 | 数据类型 | 必填 / 基数 | 值或格式约束 | 示例 | 引入版本 |
|---|---|---|---|---|---|---|---|
| `datasetId` | `http://purl.org/dc/terms/identifier` | 数据产品的唯一标识。Unique identifier of the data product. | `xsd:string` | 是，`1..1` | 单个字符串 | `building-energy-hourly-v1` | v0.1 |
| `providerName` | `https://w3id.org/dssc-demo/building-energy#providerName` | 发布数据产品的机构名称。Human-readable name of the publishing organization. | `xsd:string` | 是，`1..1` | 单个字符串 | `Energy Data Provider Ltd.` | v0.1 |
| `endpointUrl` | `https://w3id.org/dssc-demo/building-energy#endpointUrl` | 提供数据产品的 API 地址。IRI of the API endpoint exposing the data product. | IRI | 是，`1..1` | 必须是 IRI | `https://api.example.org/energy/buildings/hourly` | v0.2 |
| `format` | `https://w3id.org/dssc-demo/building-energy#format` | 数据载荷的序列化格式。Serialization format of the payload. | 字符串字面量 | 是，`1..1` | 仅 `JSON` | `JSON` | v0.1；v0.2 起强约束 |
| `frequency` | `https://w3id.org/dssc-demo/building-energy#frequency` | 数据更新或累积频率。Expected update or accrual frequency. | 字符串字面量 | 是，`1..1` | 仅 `hourly` | `hourly` | v0.1；v0.2 起强约束 |
| `unit` | `https://w3id.org/dssc-demo/building-energy#unit` | 能耗值使用的计量单位。Measurement-unit token used for energy values. | 字符串字面量 | 是，`1..1` | 仅 `kWh` | `kWh` | v0.2 |
| `spatialCoverage` | `https://w3id.org/dssc-demo/building-energy#spatialCoverage` | 数据产品覆盖的地理范围。Human-readable spatial coverage. | `xsd:string` | 是，`1..1` | 单个字符串 | `Shenzhen demo district` | v0.1 |
| `temporalStart` | `https://w3id.org/dssc-demo/building-energy#temporalStart` | 时间覆盖的起始日期（含）。Inclusive start date of temporal coverage. | `xsd:date` | 是，`1..1` | ISO 日期 | `2026-05-01` | v0.2 |
| `temporalEnd` | `https://w3id.org/dssc-demo/building-energy#temporalEnd` | 时间覆盖的结束日期（含）。Inclusive end date of temporal coverage. | `xsd:date` | 是，`1..1` | ISO 日期 | `2026-05-02` | v0.2 |
| `license` | `http://purl.org/dc/terms/license` | 数据产品许可条款地址。IRI identifying the data-product licence. | IRI | C v0.3 未定义；D profile 为可选 `0..1` | D profile 要求 HTTPS IRI | `https://creativecommons.org/licenses/by/4.0/` | 仅 D 最终验证扩展 |

## C v0.3 与 D 最终验证路径

| 业务字段 | C v0.3 语义 URI | D 最终验证路径 |
|---|---|---|
| `datasetId` | `dct:identifier` | `ex:datasetId` |
| `providerName` | `be:providerName` | `ex:providerName` |
| `endpointUrl` | `be:endpointUrl` | `dcat:endpointURL` |
| `format` | `be:format` | `dct:format`，取值 `application/json` |
| `frequency` | `be:frequency` | `dct:accrualPeriodicity` |
| `unit` | `be:unit` | `ex:unit` |
| `spatialCoverage` | `be:spatialCoverage` | `dct:spatial` |
| `temporalStart` | `be:temporalStart` | `ex:temporalStart` |
| `temporalEnd` | `be:temporalEnd` | `ex:temporalEnd` |
| `license` | C v0.3 未定义 | `dct:license` |

其中 `be:` 为 `https://w3id.org/dssc-demo/building-energy#`，`ex:` 为 `https://example.org/dssc-energy#`。两列是语义映射，不表示 URI 相同。

## Energy Reading Record（C 组 v0.3）

| 字段 | 完整 URI | 中英文定义 | 数据类型 | 必填 / 基数 | 值或格式约束 | 示例 |
|---|---|---|---|---|---|---|
| `buildingId` | `https://w3id.org/dssc-demo/building-energy#buildingId` | 建筑标识。Identifier of the building feature of interest. | `xsd:string` | 是，`1..1` | 单个字符串 | `BLD-001` |
| `meterId` | `https://w3id.org/dssc-demo/building-energy#meterId` | 电表或传感器标识。Identifier of the meter or sensor. | `xsd:string` | 是，`1..1` | 单个字符串 | `MTR-001` |
| `timestamp` | `https://w3id.org/dssc-demo/building-energy#timestamp` | 读数适用时间。Time at which the reading applies. | `xsd:dateTime` | 是，`1..1` | ISO 8601 date-time | `2026-05-01T00:00:00+08:00` |
| `energyKWh` | `https://w3id.org/dssc-demo/building-energy#energyKWh` | 以 kWh 表示的能耗值。Numeric energy consumption in kilowatt-hours. | `xsd:decimal` / 数值 | 是，`1..1` | `>= 0` | `12.4` |
| `unit` | `https://w3id.org/dssc-demo/building-energy#unit` | 读数单位。Measurement-unit token. | 字符串字面量 | 是，`1..1` | 仅 `kWh` | `kWh` |
| `location` | `https://w3id.org/dssc-demo/building-energy#location` | 读数关联地点。Place associated with the reading. | 空白节点或 IRI | 是，`1..1` | JSON-LD 节点；示例含 `city`、`district` | `{"city":"Shenzhen","district":"Nanshan"}` |

以上记录字段均属于 v0.3。
