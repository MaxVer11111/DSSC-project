# C 组交付来源登记

## 原始交付位置

| 项目 | 路径或值 |
|---|---|
| C 组原始目录 | `../B组-C组对接包/` |
| C 组原始 ZIP | `../B组-C组对接包_2026-08-10.zip` |
| ZIP SHA-256 | `68A6750D533C854DA0F940EC6BC5685C4206929A9614BDE26D1842FAD2BC6167` |
| 整理日期 | `2026-08-11` |
| 整理人 | `DSSC Group B - Member 1` |

## 关键原始文件

| 文件 | SHA-256 | 用途 |
|---|---|---|
| `model-version.json` | `FD10526232EDC7D6D937720F76605ED7FD2E2A144F95F82100E4BC16D9EC3697` | 模型版本和工件哈希基线 |
| `data-product-valid.jsonld` | `609CA2C0A75E32ABE5B470D613A7B24404628ACB2DEB3BFCA3337C936379949C` | C v0.3 原始有效样例 |
| `field-definition.md` | `F9AA6D9ADB5D8D21CC46BF0D80F98C64B5F59BCE6A412FEEE16DDF5F76064026` | 字段语义和约束 |
| `field-mapping-to-B.md` | `7EC06CA87756DA940E0F994FB4C68DDE43C35036F25446BB2D64020B617506A5` | C 组原始映射说明 |

C 组原始目录内 `SHA256SUMS.txt` 列出的 32 个文件已由成员 1 复核，哈希全部匹配。原始目录和 ZIP 不应由成员 2 修改。

## 成员 1 派生文件说明

本交接目录中的 `c-to-b-data-summary.json`、`field-mapping.md`、`a-c-consistency-matrix.md` 和 `current-demo-metadata.jsonld` 均为 B 组成员 1 的整理产物，不是 C 组原始文件。

