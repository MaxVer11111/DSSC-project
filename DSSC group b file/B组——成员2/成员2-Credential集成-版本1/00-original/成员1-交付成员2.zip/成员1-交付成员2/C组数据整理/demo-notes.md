# C 组数据的 Demo 限制说明

成员 2 在 Credential、测试报告和最终展示中保留以下说明即可。

1. C 组语义模型版本为 `v0.3`，状态为 `draft / Research demo release candidate`，不能表述为生产标准或法律认证模型。
2. `current-demo-metadata.jsonld` 是成员 1 根据 C 组模型和 A 组当前 Real Cluster 值生成的整理副本，不是 C 组原始签发文件。
3. 原始 C 组正例中的 `example.org` endpoint 是目标业务 API 示例；当前部署证据使用 A 组本地 Scorpio endpoint。
4. Scorpio endpoint 仅在本地 Real Cluster 环境可达，不是公开互联网服务。
5. C 组的 `format = JSON` 是模型约束字面量；A 组的 `application/ld+json` 是实际 HTTP media type，两者不得互相覆盖。
6. `frequency`、`unit`、空间和时间范围属于 Dataset metadata，不表示 Gaia-X LegalPerson 或 ServiceOffering 合规要求。
7. C 组 SHACL 通过只表示 metadata 满足 C v0.3 语义约束，不能替代 B 组 Gaia-X Compliance 验证。
8. D 组验证报告尚未接入，因此目前只能说明 A/C 已对齐，不能宣称完整 onboarding evidence 已闭环。

